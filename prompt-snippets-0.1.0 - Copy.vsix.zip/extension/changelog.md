# Change Log

All notable changes to the "Prompt Snippets" extension will be documented in this file.

## [0.0.1] - 2024-03-19

### Added
- Initial release
- Basic command to insert prompt snippets 